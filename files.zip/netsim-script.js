// ============================================================
// DOJO NETSIM — CLI Engine + Lab System
// Style: Le Dojo du Networking
// ============================================================

'use strict';

// ---- STATE ----
let currentLab = null;
let allLabs = [];
let checklistState = {};
let panelVisible = true;
let cliHistory = [];
let histIdx = -1;

// ---- DEVICE STATES ----
const DEVICES = {
  SW1: {
    hostname: 'SW1', mode: 'exec', configContext: null,
    vlans: { 1: 'default' },
    interfaces: {},
    portSecurity: {},
    trunk: {},
    type: 'switch'
  },
  SW2: {
    hostname: 'SW2', mode: 'exec', configContext: null,
    vlans: { 1: 'default' },
    interfaces: {},
    trunk: {},
    type: 'switch'
  },
  R1: {
    hostname: 'R1', mode: 'exec', configContext: null,
    interfaces: {},
    routes: [],
    type: 'router'
  }
};

let activeDevice = null;

// ============================================================
// INIT
// ============================================================
document.addEventListener('DOMContentLoaded', async () => {
  await loadLabs();
  const params = new URLSearchParams(window.location.search);
  const labId = parseInt(params.get('lab')) || 1;
  loadLab(labId);
  setupCLI();
  setupUI();
});

async function loadLabs() {
  try {
    const r = await fetch('labs.json');
    const data = await r.json();
    allLabs = data.labs;
  } catch(e) {
    // Fallback: try from window
    if (window.LABS_DATA) allLabs = window.LABS_DATA.labs;
  }
}

// ============================================================
// LAB LOADER
// ============================================================
function loadLab(id) {
  const lab = allLabs.find(l => l.id === id);
  if (!lab) { showError(`Lab ${id} introuvable.`); return; }

  currentLab = lab;
  checklistState = {};
  lab.checklist.forEach(c => checklistState[c.id] = false);

  // Set active device
  const dev = DEVICES[lab.initial_config];
  if (dev) {
    activeDevice = lab.initial_config;
    dev.mode = 'exec';
    dev.configContext = null;
  }

  renderLabPanel(lab);
  renderChecklist(lab);
  drawTopology(lab.topology);
  updateLabSelector(lab.id);
  updatePrompt();

  // Welcome message
  cliPrint(`\n══════════════════════════════════════════`, 'cyan');
  cliPrint(` ${lab.title}`, 'accent');
  cliPrint(` Difficulté: ${lab.difficulty} | Durée: ${lab.duration}`, 'muted');
  cliPrint(`══════════════════════════════════════════`, 'cyan');
  cliPrint(`\n Appareil actif: ${activeDevice}`, 'ok');
  cliPrint(` Tapez 'help' pour les commandes disponibles.\n`, 'muted');
  updatePrompt();
}

// ============================================================
// LAB PANEL RENDERER
// ============================================================
function renderLabPanel(lab) {
  // Title & meta
  document.getElementById('lab-title').textContent = lab.title;
  document.getElementById('lab-meta').innerHTML =
    `<span class="badge badge-diff">${lab.difficulty}</span>` +
    `<span class="badge badge-time">⏱ ${lab.duration}</span>` +
    `<span class="badge badge-obj">${lab.objectives.length} objectifs</span>`;

  // Objectives
  const objEl = document.getElementById('lab-objectives');
  objEl.innerHTML = lab.objectives.map((o, i) =>
    `<li><span class="obj-num">${i+1}</span>${o}</li>`
  ).join('');

  // Addressing table
  const tbody = document.getElementById('addr-tbody');
  tbody.innerHTML = lab.addressing.map(row =>
    `<tr>
      <td><strong>${row.device}</strong></td>
      <td><code>${row.interface}</code></td>
      <td><code class="ip">${row.ip}</code></td>
      <td><code>${row.mask}</code></td>
      <td><span class="vlan-badge">${row.vlan}</span></td>
    </tr>`
  ).join('');

  // Instructions
  const instrEl = document.getElementById('lab-instructions');
  instrEl.innerHTML = lab.instructions.map((instr, i) =>
    `<li class="instr-item">
      <span class="step-num">${i+1}</span>
      <span>${instr}</span>
    </li>`
  ).join('');

  // Hint
  document.getElementById('lab-hint').textContent = lab.hint || '';
}

// ============================================================
// TOPOLOGY SVG RENDERER
// ============================================================
function drawTopology(topo) {
  const svg = document.getElementById('topology-svg');
  if (!svg || !topo) return;

  const W = svg.clientWidth || 780;
  const H = 280;
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.innerHTML = '';

  const defs = document.createElementNS('http://www.w3.org/2000/svg','defs');
  defs.innerHTML = `
    <marker id="arr" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="#1e3a5f"/>
    </marker>
    <marker id="arr-danger" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="#ff3366"/>
    </marker>
    <marker id="arr-trunk" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
      <path d="M0,0 L0,6 L9,3 z" fill="#00d4ff"/>
    </marker>
    <filter id="glow">
      <feGaussianBlur stdDeviation="2.5" result="blur"/>
      <feComposite in="SourceGraphic" in2="blur" operator="over"/>
    </filter>
  `;
  svg.appendChild(defs);

  // Normalize positions relative to SVG width
  const scaleX = W / 780;
  const nodes = {};
  topo.devices.forEach(d => {
    nodes[d.id] = { ...d, x: d.x * scaleX };
  });

  // Draw links first
  topo.links.forEach(link => {
    const from = nodes[link.from];
    const to = nodes[link.to];
    if (!from || !to) return;

    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', from.x); line.setAttribute('y1', from.y);
    line.setAttribute('x2', to.x);   line.setAttribute('y2', to.y);

    const isDanger = link.type === 'danger';
    const isTrunk  = link.type === 'trunk';

    line.setAttribute('stroke', isDanger ? '#ff3366' : isTrunk ? '#00d4ff' : '#1e3a5f');
    line.setAttribute('stroke-width', isTrunk ? '2.5' : isDanger ? '2' : '1.5');
    if (isDanger) line.setAttribute('stroke-dasharray', '6,4');
    line.setAttribute('marker-end', `url(#arr${isDanger?'-danger':isTrunk?'-trunk':''})`);
    svg.appendChild(line);

    // Link label
    if (link.label) {
      const mx = (from.x + to.x) / 2;
      const my = (from.y + to.y) / 2;
      const lbl = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      lbl.setAttribute('x', mx + 4); lbl.setAttribute('y', my - 6);
      lbl.setAttribute('fill', isDanger ? '#ff3366' : isTrunk ? '#00d4ff' : '#5a7a9f');
      lbl.setAttribute('font-size', '10'); lbl.setAttribute('font-family', 'Share Tech Mono, monospace');
      lbl.setAttribute('text-anchor', 'middle');
      lbl.textContent = link.label;
      svg.appendChild(lbl);
    }
  });

  // Draw nodes
  topo.devices.forEach(d => {
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.setAttribute('class', `topo-node topo-${d.type}`);
    g.setAttribute('transform', `translate(${nodes[d.id].x},${d.y})`);

    const iconColor = d.color || (d.type === 'router' ? '#ff6b35' : d.type === 'switch' ? '#00d4ff' : '#5a7a9f');

    if (d.type === 'router') {
      const circle = document.createElementNS('http://www.w3.org/2000/svg','circle');
      circle.setAttribute('r','24'); circle.setAttribute('fill','#0d1525');
      circle.setAttribute('stroke', iconColor); circle.setAttribute('stroke-width','2');
      g.appendChild(circle);
      const txt = document.createElementNS('http://www.w3.org/2000/svg','text');
      txt.setAttribute('text-anchor','middle'); txt.setAttribute('dy','-2');
      txt.setAttribute('fill', iconColor); txt.setAttribute('font-size','20');
      txt.textContent = '⬡'; g.appendChild(txt);
    } else if (d.type === 'switch') {
      const rect = document.createElementNS('http://www.w3.org/2000/svg','rect');
      rect.setAttribute('x','-28'); rect.setAttribute('y','-16');
      rect.setAttribute('width','56'); rect.setAttribute('height','32');
      rect.setAttribute('rx','4'); rect.setAttribute('fill','#0d1525');
      rect.setAttribute('stroke', iconColor); rect.setAttribute('stroke-width','2');
      g.appendChild(rect);
      const txt = document.createElementNS('http://www.w3.org/2000/svg','text');
      txt.setAttribute('text-anchor','middle'); txt.setAttribute('dy','5');
      txt.setAttribute('fill', iconColor); txt.setAttribute('font-size','13');
      txt.setAttribute('font-family','Share Tech Mono,monospace');
      txt.textContent = 'SW'; g.appendChild(txt);
    } else {
      const rect = document.createElementNS('http://www.w3.org/2000/svg','rect');
      rect.setAttribute('x','-20'); rect.setAttribute('y','-14');
      rect.setAttribute('width','40'); rect.setAttribute('height','28');
      rect.setAttribute('rx','3'); rect.setAttribute('fill','#080c14');
      rect.setAttribute('stroke', iconColor); rect.setAttribute('stroke-width','1.5');
      g.appendChild(rect);
      const txt = document.createElementNS('http://www.w3.org/2000/svg','text');
      txt.setAttribute('text-anchor','middle'); txt.setAttribute('dy','4');
      txt.setAttribute('fill', iconColor); txt.setAttribute('font-size','11');
      txt.setAttribute('font-family','Share Tech Mono,monospace');
      txt.textContent = 'PC'; g.appendChild(txt);
    }

    // Device label (supports \n)
    const lines = d.label.split('\\n');
    lines.forEach((line, i) => {
      const lbl = document.createElementNS('http://www.w3.org/2000/svg','text');
      lbl.setAttribute('text-anchor','middle');
      lbl.setAttribute('y', 34 + i * 14);
      lbl.setAttribute('fill', i === 0 ? '#c8deff' : '#5a7a9f');
      lbl.setAttribute('font-size', i === 0 ? '12' : '10');
      lbl.setAttribute('font-family','Share Tech Mono,monospace');
      lbl.textContent = line;
      g.appendChild(lbl);
    });

    svg.appendChild(g);
  });
}

// ============================================================
// CHECKLIST RENDERER
// ============================================================
function renderChecklist(lab) {
  const el = document.getElementById('checklist-items');
  if (!el || !lab.checklist) return;

  el.innerHTML = lab.checklist.map(item => `
    <div class="check-item ${checklistState[item.id] ? 'done' : ''}" id="chk-${item.id}">
      <div class="check-icon">${checklistState[item.id] ? '✅' : '○'}</div>
      <div class="check-label">${item.label}</div>
      <code class="check-cmd">${item.command}</code>
    </div>
  `).join('');

  updateScore();
}

function updateScore() {
  const total = currentLab.checklist.length;
  const done = Object.values(checklistState).filter(Boolean).length;
  const pct = Math.round(done / total * 100);

  document.getElementById('score-text').textContent = `${done}/${total}`;
  document.getElementById('score-bar-fill').style.width = pct + '%';
  document.getElementById('score-bar-fill').style.background =
    pct === 100 ? 'var(--ok)' : pct >= 50 ? 'var(--wa)' : 'var(--ac)';

  if (pct === 100) {
    document.getElementById('feedback-msg').innerHTML =
      `<div class="feedback-win">🎉 Lab complété ! Toutes les vérifications passent.</div>`;
  }
}

function tryCheck(commandOutput, command) {
  if (!currentLab) return;
  currentLab.checklist.forEach(item => {
    if (checklistState[item.id]) return;
    const cmdMatch = command.toLowerCase().includes(item.command.split(' ')[0].toLowerCase()) ||
                     item.command.toLowerCase().includes(command.split(' ')[0].toLowerCase());
    if (!cmdMatch) return;

    const re = new RegExp(item.expect, 'i');
    if (re.test(commandOutput)) {
      checklistState[item.id] = true;
      const el = document.getElementById(`chk-${item.id}`);
      if (el) {
        el.classList.add('done');
        el.querySelector('.check-icon').textContent = '✅';
      }
      cliPrint(`\n  ✅ Objectif validé : ${item.label}`, 'ok');
      updateScore();
    }
  });
}

// ============================================================
// CLI ENGINE
// ============================================================
function setupCLI() {
  const inp = document.getElementById('cli-input');
  if (!inp) return;

  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const raw = inp.value;
      executeCommand(raw);
      cliHistory.unshift(raw);
      histIdx = -1;
      inp.value = '';
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (histIdx < cliHistory.length - 1) histIdx++;
      inp.value = cliHistory[histIdx] || '';
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (histIdx > 0) histIdx--;
      else { histIdx = -1; inp.value = ''; return; }
      inp.value = cliHistory[histIdx] || '';
    } else if (e.ctrlKey && e.key === 'c') {
      cliPrint('^C', 'warn');
      inp.value = '';
    } else if (e.ctrlKey && e.key === 'l') {
      e.preventDefault();
      clearCLI();
    }
  });

  document.getElementById('cli-area').addEventListener('click', () => inp.focus());
}

function executeCommand(raw) {
  const dev = DEVICES[activeDevice];
  if (!dev) return;
  const prompt = getPrompt(dev);

  cliPrint(`${prompt} ${raw}`, 'prompt-echo');

  const cmd = raw.trim();
  if (!cmd) { updatePrompt(); return; }

  const output = dispatchCommand(dev, cmd);
  if (output !== null) {
    cliPrint(output, 'output');
    tryCheck(output, cmd);
  }

  updatePrompt();
}

function getPrompt(dev) {
  const h = dev.hostname;
  if (dev.mode === 'exec') return `${h}>`;
  if (dev.mode === 'priv') return `${h}#`;
  if (dev.configContext) return `${h}(${dev.configContext})#`;
  return `${h}(config)#`;
}

function updatePrompt() {
  const dev = DEVICES[activeDevice];
  if (!dev) return;
  document.getElementById('cli-prompt').textContent = getPrompt(dev) + ' ';
  document.getElementById('cli-device-label').textContent = `[${activeDevice}]`;
}

// ============================================================
// COMMAND DISPATCHER
// ============================================================
function dispatchCommand(dev, raw) {
  const parts = raw.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();
  const rest = parts.slice(1).join(' ');

  // ---- Navigation ----
  if (cmd === 'enable') {
    dev.mode = 'priv'; return '';
  }
  if (cmd === 'disable') {
    dev.mode = 'exec'; return '';
  }
  if ((cmd === 'configure' || cmd === 'conf') && /^t/i.test(rest)) {
    if (dev.mode !== 'priv') return `% Error: not in privileged EXEC mode`;
    dev.mode = 'config'; dev.configContext = null;
    return 'Enter configuration commands, one per line.  End with CNTL/Z.';
  }
  if (cmd === 'end' || (cmd === 'ctrl' && rest === 'z')) {
    dev.mode = 'priv'; dev.configContext = null; return '';
  }
  if (cmd === 'exit') {
    if (dev.configContext) { dev.configContext = null; return ''; }
    if (dev.mode === 'config') { dev.mode = 'priv'; return ''; }
    if (dev.mode === 'priv') { dev.mode = 'exec'; return ''; }
    return '';
  }

  // ---- Help ----
  if (cmd === 'help' || cmd === '?') {
    return cmdHelp(dev);
  }

  // ---- Show commands ----
  if (cmd === 'show') return cmdShow(dev, parts.slice(1));

  // ---- Config mode commands ----
  if (dev.mode === 'config' || dev.configContext) {
    return cmdConfig(dev, cmd, parts, rest, raw);
  }

  // ---- Priv EXEC ----
  if (cmd === 'ping') return cmdPing(dev, parts.slice(1));
  if (cmd === 'traceroute') return cmdTraceroute(dev, parts.slice(1));
  if (cmd === 'clear') return cmdClear(dev, parts.slice(1));
  if (cmd === 'copy') return 'Building configuration...\n[OK]';
  if (cmd === 'write' || (cmd === 'wr' && !rest)) return 'Building configuration...\n[OK]';
  if (cmd === 'reload') return `\nSystem configuration has been modified. Save? [yes/no]: `;
  if (cmd === 'debug') return `%Warning: Debugging is very processor intensive. Debugging output is on.`;
  if (cmd === 'undebug' || cmd === 'no debug') return `All possible debugging has been turned off.`;
  if (cmd === 'clock') return cmdClock(rest);
  if (cmd === 'hostname') { dev.hostname = rest || dev.hostname; return ''; }

  // ---- Tab key simulation ----
  if (raw.endsWith('?')) return cmdHelp(dev, raw);

  return `% Unknown command or computer in command: '${parts[0]}'\n% Type "help" or "?" for available commands.`;
}

// ============================================================
// CONFIG MODE
// ============================================================
function cmdConfig(dev, cmd, parts, rest, raw) {
  // Interface context
  if (cmd === 'interface' || cmd === 'int') {
    const ifName = parts.slice(1).join('').replace(/\s+/g, '');
    if (!ifName) return '% Incomplete command.';
    dev.configContext = `config-if:${ifName}`;
    if (!dev.interfaces[ifName]) dev.interfaces[ifName] = {};
    return '';
  }

  // VLAN context (switches only)
  if (cmd === 'vlan' && dev.type === 'switch') {
    const vid = parseInt(parts[1]);
    if (isNaN(vid)) return '% Incomplete command.';
    dev.configContext = `config-vlan:${vid}`;
    if (!dev.vlans[vid]) dev.vlans[vid] = '';
    return '';
  }

  // Router OSPF
  if (cmd === 'router') {
    if (/ospf/i.test(rest)) {
      dev.configContext = 'config-router';
      return '';
    }
    if (/eigrp/i.test(rest)) { dev.configContext = 'config-router'; return ''; }
    if (/bgp/i.test(rest)) { dev.configContext = 'config-router'; return ''; }
    if (/rip/i.test(rest)) { dev.configContext = 'config-router'; return ''; }
  }

  // Line context
  if (cmd === 'line') {
    dev.configContext = 'config-line';
    return '';
  }

  // ---- VLAN name (in vlan context) ----
  if (cmd === 'name' && dev.configContext && dev.configContext.startsWith('config-vlan:')) {
    const vid = parseInt(dev.configContext.split(':')[1]);
    dev.vlans[vid] = rest;
    return '';
  }

  // ---- Interface commands ----
  if (dev.configContext && dev.configContext.startsWith('config-if:')) {
    const ifName = dev.configContext.split(':')[1];
    if (!dev.interfaces[ifName]) dev.interfaces[ifName] = {};
    const iface = dev.interfaces[ifName];

    // IP address
    if (cmd === 'ip' && /^address/i.test(rest)) {
      const m = rest.match(/address\s+(\S+)\s+(\S+)/i);
      if (m) { iface.ip = m[1]; iface.mask = m[2]; iface.status = 'up'; return ''; }
    }
    // IPv6
    if (cmd === 'ipv6' && /^address/i.test(rest)) {
      iface.ipv6 = rest.replace(/^address\s+/i,''); return '';
    }
    // No shutdown
    if (cmd === 'no' && /^shutdown/i.test(rest)) {
      iface.status = 'up';
      return `%LINK-5-CHANGED: Interface ${ifName}, changed state to up\n%LINEPROTO-5-UPDOWN: Line protocol on Interface ${ifName}, changed state to up`;
    }
    if (cmd === 'shutdown') {
      iface.status = 'down';
      return `%LINK-5-CHANGED: Interface ${ifName}, changed state to administratively down`;
    }
    // Description
    if (cmd === 'description') { iface.description = rest; return ''; }
    // Duplex / speed
    if (cmd === 'duplex') { iface.duplex = rest; return ''; }
    if (cmd === 'speed') { iface.speed = rest; return ''; }

    // ---- SWITCH commands ----
    if (dev.type === 'switch') {
      if (cmd === 'switchport') {
        if (/^mode\s+access/i.test(rest)) { iface.swMode = 'access'; return ''; }
        if (/^mode\s+trunk/i.test(rest)) {
          iface.swMode = 'trunk'; iface.status='up';
          dev.trunk[ifName] = { native: 1, allowed: 'all' };
          return '';
        }
        if (/^mode\s+dynamic\s+desirable/i.test(rest)) { iface.swMode = 'dynamic desirable'; return ''; }
        if (/^mode\s+dynamic\s+auto/i.test(rest)) { iface.swMode = 'dynamic auto'; return ''; }
        if (/^access\s+vlan\s+(\d+)/i.test(rest)) {
          const m = rest.match(/vlan\s+(\d+)/i);
          if (m) { iface.accessVlan = parseInt(m[1]); return ''; }
        }
        if (/^trunk\s+native\s+vlan\s+(\d+)/i.test(rest)) {
          const m = rest.match(/vlan\s+(\d+)/i);
          if (m && dev.trunk[ifName]) { dev.trunk[ifName].native = parseInt(m[1]); return ''; }
        }
        if (/^trunk\s+allowed\s+vlan\s+([\d,]+)/i.test(rest)) {
          const m = rest.match(/vlan\s+([\d,]+)/i);
          if (m && dev.trunk[ifName]) { dev.trunk[ifName].allowed = m[1]; return ''; }
        }
        if (/^nonegotiate/i.test(rest)) { return ''; }
        if (/^port-security$/i.test(rest)) {
          if (!iface.portSecurity) iface.portSecurity = { enabled: true, max: 1, mode: 'shutdown', sticky: false, current: 0 };
          iface.portSecurity.enabled = true;
          return '';
        }
        if (/^port-security\s+maximum\s+(\d+)/i.test(rest)) {
          const m = rest.match(/maximum\s+(\d+)/i);
          if (m) {
            if (!iface.portSecurity) iface.portSecurity = { enabled: true, max: 1, mode: 'shutdown', sticky: false, current: 0 };
            iface.portSecurity.max = parseInt(m[1]);
          }
          return '';
        }
        if (/^port-security\s+violation\s+(\w+)/i.test(rest)) {
          const m = rest.match(/violation\s+(\w+)/i);
          if (m) {
            if (!iface.portSecurity) iface.portSecurity = { enabled: true, max: 1, mode: 'shutdown', sticky: false, current: 0 };
            iface.portSecurity.mode = m[1].toLowerCase();
          }
          return '';
        }
        if (/^port-security\s+mac-address\s+sticky/i.test(rest)) {
          if (!iface.portSecurity) iface.portSecurity = { enabled: true, max: 1, mode: 'shutdown', sticky: false, current: 0 };
          iface.portSecurity.sticky = true;
          return '';
        }
        if (/^port-security\s+mac-address\s+([\w.]+)/i.test(rest)) {
          const m = rest.match(/mac-address\s+([\w.]+)/i);
          if (m && iface.portSecurity) iface.portSecurity.staticMac = m[1];
          return '';
        }
      }
      // spanning-tree
      if (cmd === 'spanning-tree') {
        if (/portfast/i.test(rest)) { iface.portfast = true; return '%Warning: portfast should only be enabled on ports connected to a single host.'; }
        if (/bpduguard\s+enable/i.test(rest)) { iface.bpduguard = true; return ''; }
        return '';
      }
    }

    // ---- ROUTER sub-interface ----
    if (dev.type === 'router') {
      if (cmd === 'encapsulation' && /^dot1q?\s+(\d+)/i.test(rest)) {
        const m = rest.match(/\d+/);
        if (m) { iface.dot1q = parseInt(m[0]); iface.status='up'; return ''; }
      }
      if (cmd === 'ip' && /^nat/i.test(rest)) {
        iface.nat = /inside/i.test(rest) ? 'inside' : 'outside'; return '';
      }
    }

    return `% Invalid input detected at '^' marker in config-if mode`;
  }

  // ---- Global config commands ----
  if (cmd === 'hostname') { dev.hostname = rest; return ''; }
  if (cmd === 'enable' && /^secret/i.test(rest)) { return ''; }
  if (cmd === 'enable' && /^password/i.test(rest)) { return ''; }
  if (cmd === 'service' && /^password-encryption/i.test(rest)) { return ''; }
  if (cmd === 'no' && /^ip\s+domain.lookup/i.test(rest)) { return ''; }
  if (cmd === 'ip' && /^routing/i.test(rest)) { dev.routing = true; return ''; }
  if (cmd === 'ip' && /^domain.name/i.test(rest)) { return ''; }
  if (cmd === 'crypto') { return 'Generating 2048 bit RSA keys, keys will be non-exportable...\n[OK] (elapsed time was 1 seconds)'; }
  if (cmd === 'ip' && /^ssh/i.test(rest)) { return ''; }
  if (cmd === 'banner') { return ''; }
  if (cmd === 'logging') { return ''; }
  if (cmd === 'ntp') { return ''; }
  if (cmd === 'snmp') { return ''; }
  if (cmd === 'access-list') {
    const m = raw.match(/access-list\s+(\d+)\s+(\w+)\s+(\S+)/i);
    if (m) { if (!dev.acls) dev.acls = {}; dev.acls[m[1]] = (dev.acls[m[1]]||[]).concat([{action:m[2],src:m[3]}]); return ''; }
    return '';
  }
  if (cmd === 'ip' && /^access-list/i.test(rest)) { return ''; }
  // NAT
  if (cmd === 'ip' && /^nat\s+inside\s+source/i.test(rest)) { return ''; }
  if (cmd === 'ip' && /^nat/i.test(rest)) { return ''; }
  // VTP
  if (cmd === 'vtp') { return ''; }
  // spanning-tree global
  if (cmd === 'spanning-tree') {
    if (/portfast\s+default/i.test(rest)) { dev.portfastDefault = true; return ''; }
    if (/mode\s+rapid-pvst/i.test(rest)) { dev.stpMode = 'rapid-pvst'; return ''; }
    if (/mode\s+pvst/i.test(rest)) { dev.stpMode = 'pvst'; return ''; }
    return '';
  }
  if (cmd === 'errdisable') { return ''; }

  // OSPF / routing config-router
  if (dev.configContext === 'config-router') {
    if (cmd === 'network') { if (!dev.routes) dev.routes=[]; dev.routes.push(rest); return ''; }
    if (cmd === 'router-id') { dev.routerId = rest; return ''; }
    if (cmd === 'passive-interface') { return ''; }
    if (cmd === 'auto-cost') { return ''; }
    if (cmd === 'neighbor') { return ''; }
    return '';
  }

  // Line config
  if (dev.configContext === 'config-line') {
    if (cmd === 'transport') { return ''; }
    if (cmd === 'login') { return ''; }
    if (cmd === 'password') { return ''; }
    if (cmd === 'exec-timeout') { return ''; }
    return '';
  }

  if (cmd === 'no') {
    // Handle 'no interface ...' or other no commands
    return '';
  }

  if (cmd === 'interface' || cmd === 'int') { return '% interface command missing subcommand'; }

  return `% Invalid input detected: '${parts[0]}'`;
}

// ============================================================
// SHOW COMMANDS
// ============================================================
function cmdShow(dev, args) {
  const sub = (args[0] || '').toLowerCase();
  const sub2 = (args[1] || '').toLowerCase();
  const sub3 = (args[2] || '').toLowerCase();

  // show version
  if (sub === 'version') {
    return `Cisco IOS Software, Version 15.2(4)M6, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
ROM: System Bootstrap, Version 15.1(4)M10
${dev.hostname} uptime is 2 days, 14 hours, 22 minutes
System returned to ROM by reload
Cisco 2900 Series Router (revision 1.0)
System image file is "flash0:c2900-universalk9-mz.SPA.152-4.M6.bin"
IOS: 15.2(4)M6   Platform: Cisco 2951`;
  }

  // show running-config
  if (sub === 'running-config' || (sub === 'run' && !sub2)) {
    return buildRunningConfig(dev);
  }

  // show startup-config
  if (sub === 'startup-config') {
    return 'startup-config is not present\n(Use "copy running-config startup-config" to save)';
  }

  // show ip interface brief
  if (sub === 'ip' && sub2 === 'interface' && sub3.startsWith('b')) {
    return buildIpIntBrief(dev);
  }

  // show interfaces
  if (sub === 'interfaces') {
    if (args[1]) return buildInterfaceDetail(dev, args.slice(1).join(''));
    return buildAllInterfaces(dev);
  }
  if (sub === 'interface') {
    return buildInterfaceDetail(dev, args.slice(1).join(''));
  }

  // show interfaces trunk
  if (sub === 'interfaces' && sub2 === 'trunk') {
    return buildTrunk(dev);
  }

  // show ip route
  if (sub === 'ip' && sub2 === 'route') {
    return buildRoutes(dev);
  }

  // show ip ospf neighbor
  if (sub === 'ip' && sub2 === 'ospf' && sub3 === 'neighbor') {
    return buildOspfNeighbor(dev);
  }
  if (sub === 'ip' && sub2 === 'ospf') {
    return `Routing Process "ospf 1" with ID ${dev.routerId||'1.1.1.1'}\n Start time: 00:00:05.240, Time elapsed: 02:14:33.240\n Supports only single TOS(TOS0) routes\n Number of areas in this router is 1. 1 normal 0 stub 0 nssa`;
  }

  // show vlan / vlan brief
  if (sub === 'vlan') {
    return buildVlanBrief(dev);
  }

  // show mac address-table
  if (sub === 'mac' || (sub === 'mac' && sub2 === 'address-table')) {
    return buildMacTable(dev);
  }

  // show port-security
  if (sub === 'port-security') {
    if (args[1] && args[1].toLowerCase() === 'interface') {
      return buildPortSecurityInterface(dev, args[2] || '');
    }
    return buildPortSecurity(dev);
  }

  // show interfaces trunk
  if (sub === 'interfaces' && sub2 === 'trunk') {
    return buildTrunk(dev);
  }
  if (sub === 'interface' && args.length > 1 && !/^b/i.test(sub2)) {
    return buildInterfaceDetail(dev, args.slice(1).join(' '));
  }

  // show spanning-tree
  if (sub === 'spanning-tree') {
    return buildStp(dev, args.slice(1));
  }

  // show cdp neighbors
  if (sub === 'cdp') {
    return `Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge\n                  S - Switch, H - Host, I - IGMP, r - Repeater\nDevice ID        Local Intrfce     Holdtme    Capability  Platform  Port ID\nSW2              Gi 0/1            177            S       WS-C2960  Gi 0/1`;
  }

  // show ssh
  if (sub === 'ssh') {
    return `SSH Enabled - version 2.0\nAuthentication methods:publickey,keyboard-interactive,password\nEncryption Algorithms:aes128-ctr,aes192-ctr,aes256-ctr\nAuthentication timeout: 120 secs; Authentication retries: 3`;
  }

  // show clock
  if (sub === 'clock') {
    return `*${new Date().toTimeString().split(' ')[0]} UTC ${new Date().toDateString()}`;
  }

  // show users
  if (sub === 'users') {
    return `    Line       User       Host(s)              Idle       Location\n*  0 con 0                idle                 00:00:00`;
  }

  // show history
  if (sub === 'history') {
    return cliHistory.slice(0, 20).map((h,i) => `  ${i+1}  ${h}`).join('\n');
  }

  // show ip nat translations
  if (sub === 'ip' && sub2 === 'nat') {
    return `Pro Inside global      Inside local       Outside local      Outside global\n--- ---               ---                ---                ---`;
  }

  // show access-lists
  if (sub === 'access-lists' || (sub === 'ip' && sub2 === 'access-lists')) {
    if (!dev.acls || Object.keys(dev.acls).length === 0) return `% There are no access lists`;
    return Object.entries(dev.acls).map(([num, rules]) =>
      `Standard IP access list ${num}\n` + rules.map((r,i) => `    ${10*(i+1)} ${r.action} ${r.src}`).join('\n')
    ).join('\n');
  }

  return `% Unknown show sub-command: 'show ${args.join(' ')}'`;
}

// ============================================================
// SHOW BUILDERS
// ============================================================
function buildRunningConfig(dev) {
  let cfg = `!\nversion 15.2\nservice timestamps debug datetime msec\nservice timestamps log datetime msec\nno service password-encryption\n!\nhostname ${dev.hostname}\n!\n`;

  if (dev.type === 'switch') {
    Object.entries(dev.vlans).filter(([id]) => id > 1).forEach(([id, name]) => {
      cfg += `vlan ${id}\n name ${name}\n!\n`;
    });
  }

  Object.entries(dev.interfaces).forEach(([name, iface]) => {
    cfg += `interface ${name}\n`;
    if (iface.description) cfg += ` description ${iface.description}\n`;
    if (iface.ip) cfg += ` ip address ${iface.ip} ${iface.mask}\n`;
    if (iface.ipv6) cfg += ` ipv6 address ${iface.ipv6}\n`;
    if (iface.dot1q) cfg += ` encapsulation dot1Q ${iface.dot1q}\n`;
    if (iface.swMode === 'access') {
      cfg += ` switchport mode access\n`;
      if (iface.accessVlan) cfg += ` switchport access vlan ${iface.accessVlan}\n`;
    }
    if (iface.swMode === 'trunk') {
      cfg += ` switchport mode trunk\n`;
    }
    if (iface.portSecurity?.enabled) {
      cfg += ` switchport port-security\n`;
      if (iface.portSecurity.max > 1) cfg += ` switchport port-security maximum ${iface.portSecurity.max}\n`;
      if (iface.portSecurity.sticky) cfg += ` switchport port-security mac-address sticky\n`;
      if (iface.portSecurity.mode !== 'shutdown') cfg += ` switchport port-security violation ${iface.portSecurity.mode}\n`;
    }
    if (iface.status === 'down') cfg += ` shutdown\n`;
    cfg += `!\n`;
  });

  cfg += `!\nend`;
  return cfg;
}

function buildIpIntBrief(dev) {
  const header = 'Interface                  IP-Address      OK? Method Status                Protocol';
  const lines = [header];
  const commonIfaces = dev.type === 'router'
    ? ['GigabitEthernet0/0','GigabitEthernet0/1','GigabitEthernet0/2']
    : ['GigabitEthernet0/1','GigabitEthernet0/2','FastEthernet0/1','FastEthernet0/2'];

  const allIfaces = [...new Set([...commonIfaces, ...Object.keys(dev.interfaces)])];

  allIfaces.forEach(name => {
    const iface = dev.interfaces[name] || {};
    const ip = iface.ip || 'unassigned';
    const ok = iface.ip ? 'YES' : 'YES';
    const method = iface.ip ? 'manual' : 'unset';
    const status = iface.status === 'down' ? 'administratively down' : (iface.ip || iface.status === 'up') ? 'up' : 'down';
    const proto = status === 'up' ? 'up' : 'down';
    lines.push(`${name.padEnd(27)}${ip.padEnd(16)}${ok}  ${method.padEnd(7)}${status.padEnd(22)}${proto}`);
  });

  return lines.join('\n');
}

function buildInterfaceDetail(dev, ifName) {
  ifName = ifName.replace(/\s/g,'');
  const iface = dev.interfaces[ifName] || {};
  const status = iface.status === 'down' ? 'administratively down' : 'up';
  const lineProto = status === 'up' ? 'up' : 'down';
  return `${ifName} is ${status}, line protocol is ${lineProto}
  Hardware is Gigabit Ethernet, address is aabb.cc${Math.floor(Math.random()*9000+1000).toString(16)}.${Math.floor(Math.random()*9000+1000).toString(16)}
  ${iface.ip ? `Internet address is ${iface.ip}/${iface.mask ? maskToPrefix(iface.mask) : '24'}` : 'Internet address is not set'}
  MTU 1500 bytes, BW 1000000 Kbit/sec, DLY 10 usec,
  reliability 255/255, txload 1/255, rxload 1/255
  Encapsulation ${iface.dot1q ? `802.1Q Virtual LAN, Vlan ID  ${iface.dot1q}.` : 'ARPA'}, loopback not set
  ${iface.duplex || 'Full'}-duplex, ${iface.speed || '100'}Mb/s, media type is T
  Last input 00:00:04, output 00:00:01, output hang never
  5 minute input rate 0 bits/sec, 0 packets/sec
  5 minute output rate 0 bits/sec, 0 packets/sec`;
}

function buildAllInterfaces(dev) {
  if (Object.keys(dev.interfaces).length === 0) {
    return buildInterfaceDetail(dev, dev.type === 'router' ? 'GigabitEthernet0/0' : 'GigabitEthernet0/1');
  }
  return Object.keys(dev.interfaces).map(n => buildInterfaceDetail(dev, n)).join('\n\n');
}

function buildVlanBrief(dev) {
  if (dev.type !== 'switch') return `% Invalid command for this device type`;
  let out = `VLAN Name                             Status    Ports\n---- -------------------------------- --------- -------`;
  out += `\n1    default                          active    `;

  // Add unassigned ports
  const assignedPorts = new Set();
  Object.entries(dev.interfaces).forEach(([name, iface]) => {
    if (iface.accessVlan) assignedPorts.add(name);
  });

  const defaultPorts = ['Fa0/3','Fa0/4','Fa0/5','Gi0/2'].filter(p => !assignedPorts.has(p));
  out += defaultPorts.join(', ');

  Object.entries(dev.vlans).filter(([id]) => parseInt(id) > 1).forEach(([id, name]) => {
    const ports = Object.entries(dev.interfaces)
      .filter(([,iface]) => iface.accessVlan === parseInt(id))
      .map(([n]) => n.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi'));
    out += `\n${id.padEnd(5)}${(name||`VLAN${id}`).padEnd(33)}active    ${ports.join(', ')}`;
  });

  out += `\n1002 fddi-default                     act/unsup\n1003 token-ring-default               act/unsup\n1004 fddinet-default                  act/unsup\n1005 trnet-default                    act/unsup`;
  return out;
}

function buildTrunk(dev) {
  const trunkIfaces = Object.entries(dev.interfaces).filter(([,i]) => i.swMode === 'trunk');
  if (trunkIfaces.length === 0) {
    return `% No trunk interfaces configured`;
  }
  let out = `Port      Mode         Encaps  Status        Native vlan\n`;
  trunkIfaces.forEach(([name, iface]) => {
    const t = dev.trunk[name] || { native: 1, allowed: '1-4094' };
    const shortName = name.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi');
    out += `${shortName.padEnd(10)}on           802.1q  trunking      ${t.native}\n`;
  });
  out += `\nPort      Vlans allowed on trunk\n`;
  trunkIfaces.forEach(([name]) => {
    const t = dev.trunk[name] || { native: 1, allowed: '1,10,20,99' };
    const shortName = name.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi');
    out += `${shortName.padEnd(10)}${t.allowed}\n`;
  });
  return out;
}

function buildPortSecurity(dev) {
  const psIfaces = Object.entries(dev.interfaces).filter(([,i]) => i.portSecurity?.enabled);
  if (psIfaces.length === 0) return `% Port security is not configured on any interfaces`;

  let out = `Secure Port  MaxSecureAddr  CurrentAddr  SecurityViolation  Security Action\n              (Count)       (Count)          (Count)\n--------------------------------------------------------------------\n`;
  psIfaces.forEach(([name, iface]) => {
    const ps = iface.portSecurity;
    const shortName = name.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi');
    out += `     ${shortName.padEnd(9)}  ${ps.max.toString().padEnd(15)}${(ps.current||0).toString().padEnd(13)}${(ps.violations||0).toString().padEnd(20)}${ps.mode.charAt(0).toUpperCase()+ps.mode.slice(1)}\n`;
  });
  out += `\nTotal Addresses in System (excluding one mac per port)     : 0\nMax Addresses limit in System (excluding one mac per port) : 4096`;
  return out;
}

function buildPortSecurityInterface(dev, ifName) {
  const iface = dev.interfaces[ifName] || {};
  const ps = iface.portSecurity;
  if (!ps?.enabled) return `% Port security is not configured on interface ${ifName}`;
  return `Port Security              : Enabled
Port Status                : Secure-up
Violation Mode             : ${ps.mode.charAt(0).toUpperCase()+ps.mode.slice(1)}
Aging Time                 : 0 mins
Aging Type                 : Absolute
SecureStatic Address Aging : Disabled
Maximum MAC Addresses      : ${ps.max}
Total MAC Addresses        : ${ps.current||0}
Configured MAC Addresses   : ${ps.staticMac ? 1 : 0}
Sticky MAC Addresses       : ${ps.sticky ? ps.current||0 : 0}
Last Source Address:Vlan   : 0000.0000.0000:0
Security Violation Count   : ${ps.violations||0}`;
}

function buildMacTable(dev) {
  let out = `          Mac Address Table\n-------------------------------------------\nVlan    Mac Address       Type        Ports\n----    -----------       --------    -----\n`;
  Object.entries(dev.interfaces).forEach(([name, iface]) => {
    if (iface.accessVlan || iface.swMode === 'access') {
      const mac = `${randomHex(4)}.${randomHex(4)}.${randomHex(4)}`;
      const vlan = iface.accessVlan || 1;
      const shortName = name.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi');
      out += `   ${vlan.toString().padEnd(5)}  ${mac.padEnd(18)}DYNAMIC     ${shortName}\n`;
    }
  });
  out += `Total Mac Addresses for this criterion: ${Object.keys(dev.interfaces).length}`;
  return out;
}

function buildRoutes(dev) {
  let out = `Codes: C - connected, S - static, R - RIP, M - mobile, B - BGP\n       D - EIGRP, EX - EIGRP external, O - OSPF, IA - OSPF inter area\n       N1 - OSPF NSSA external type 1, N2 - OSPF NSSA external type 2\n       E1 - OSPF external type 1, E2 - OSPF external type 2\n       i - IS-IS, su - IS-IS summary, L1 - IS-IS level-1, L2 - IS-IS level-2\n       ia - IS-IS inter area, * - candidate default\n\nGateway of last resort is not set\n\n`;

  Object.entries(dev.interfaces).forEach(([name, iface]) => {
    if (iface.ip && iface.status !== 'down') {
      const prefix = ipToNetwork(iface.ip, iface.mask);
      const shortName = name.replace('FastEthernet','Fa').replace('GigabitEthernet','Gi');
      out += `C     ${prefix} is directly connected, ${shortName}\n`;
      out += `L     ${iface.ip}/32 is directly connected, ${shortName}\n`;
    }
  });

  if (!out.includes('is directly connected')) out += `% No routes found`;
  return out;
}

function buildOspfNeighbor(dev) {
  return `Neighbor ID     Pri   State           Dead Time   Address         Interface\n2.2.2.2           1   FULL/DR         00:00:34    10.0.12.2       GigabitEthernet0/0`;
}

function buildStp(dev, args) {
  const vlan = args.find(a => /^\d+$/.test(a)) || '1';
  return `VLAN${vlan.padStart(4,'0')}\n  Spanning tree enabled protocol ${dev.stpMode||'ieee'}\n  Root ID    Priority    32769\n             Address     aabb.cc00.0100\n             This bridge is the root\n\n  Bridge ID  Priority    32769  (priority 32768 sys-id-ext 1)\n             Address     aabb.cc00.0100\n             Hello Time   2 sec  Max Age 20 sec  Forward Delay 15 sec\n\nInterface           Role Sts Cost      Prio.Nbr Type\n------------------- ---- --- --------- -------- --------------------------------\nGi0/1               Desg FWD 4         128.1    P2p\nFa0/1               Desg FWD 19        128.2    P2p Peer(STP)`;
}

// ---- Misc commands ----
function cmdPing(dev, args) {
  const target = args[0];
  if (!target) return `Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to , timeout is 2 seconds:\n\nSuccess rate is 0 percent (0/5)`;
  const success = Math.random() > 0.1;
  const dots = success ? '!!!!!' : '.....';
  const rate = success ? `100 percent (5/5), round-trip min/avg/max = 1/2/4 ms` : `0 percent (0/5)`;
  return `Type escape sequence to abort.\nSending 5, 100-byte ICMP Echos to ${target}, timeout is 2 seconds:\n${dots}\nSuccess rate is ${rate}`;
}

function cmdTraceroute(dev, args) {
  const target = args[0] || '8.8.8.8';
  return `Type escape sequence to abort.\nTracing the route to ${target}\nVRF info: (vrf in name/id, vrf out name/id)\n  1 192.168.1.1 4 msec 4 msec 4 msec\n  2 10.0.0.1 8 msec 8 msec 8 msec\n  3 ${target} 12 msec 12 msec 12 msec`;
}

function cmdClear(dev, args) {
  if (args[0] === 'mac' || args[1] === 'address-table') {
    Object.values(dev.interfaces).forEach(i => { delete i.learnedMacs; });
    return '';
  }
  if (args[0] === 'port-security') {
    Object.values(dev.interfaces).forEach(i => { if(i.portSecurity) i.portSecurity.current=0; });
    return '';
  }
  return '';
}

function cmdClock(rest) {
  return `Clock set to ${new Date().toTimeString().split(' ')[0]} UTC\n*${new Date().toDateString()}`;
}

function cmdHelp(dev, context) {
  return `Available commands:
  enable                   Enter privileged EXEC mode
  disable                  Exit privileged EXEC mode
  configure terminal       Enter global configuration mode
  show version             Display system information
  show running-config      Display running configuration
  show ip interface brief  Display IP interface summary
  show interfaces          Display interface details
  show vlan brief          Display VLAN assignments (switch)
  show interfaces trunk    Display trunk interfaces (switch)
  show port-security       Display port security status (switch)
  show mac address-table   Display MAC address table (switch)
  show ip route            Display routing table (router)
  show ip ospf neighbor    Display OSPF neighbors (router)
  show spanning-tree       Display STP status
  show cdp neighbors       Display CDP neighbors
  ping <ip>                Test connectivity
  traceroute <ip>          Trace route to destination
  copy running-config startup-config  Save configuration
  write memory (wr)        Save configuration
  clear port-security      Reset port security counters
  clear mac address-table  Clear MAC address table
  Ctrl+C / end             Exit to privileged EXEC
  Ctrl+L                   Clear screen`;
}

// ============================================================
// CLI OUTPUT
// ============================================================
function cliPrint(text, type = 'output') {
  const out = document.getElementById('cli-output');
  if (!out) return;

  const span = document.createElement('span');
  span.className = `cli-${type}`;

  if (type === 'prompt-echo') {
    span.innerHTML = `<span class="cli-prompt-color">${escapeHtml(text.split(' ')[0])}</span> <span class="cli-cmd">${escapeHtml(text.slice(text.indexOf(' ')+1))}</span>`;
  } else {
    span.textContent = text;
  }

  out.appendChild(span);
  out.appendChild(document.createTextNode('\n'));
  out.scrollTop = out.scrollHeight;
}

function clearCLI() {
  document.getElementById('cli-output').innerHTML = '';
}

// ============================================================
// UI SETUP
// ============================================================
function setupUI() {
  // Lab selector dropdown
  const sel = document.getElementById('lab-selector');
  if (sel) {
    allLabs.forEach(lab => {
      const opt = document.createElement('option');
      opt.value = lab.id;
      opt.textContent = `Lab ${lab.id}: ${lab.title}`;
      sel.appendChild(opt);
    });
    sel.addEventListener('change', () => {
      const id = parseInt(sel.value);
      window.history.pushState({}, '', `?lab=${id}`);
      resetDevices();
      loadLab(id);
    });
  }

  // Toggle panel
  document.getElementById('btn-toggle-panel')?.addEventListener('click', togglePanel);

  // PDF export
  document.getElementById('btn-pdf')?.addEventListener('click', exportPDF);

  // Clear CLI button
  document.getElementById('btn-clear-cli')?.addEventListener('click', clearCLI);

  // Run checklist
  document.getElementById('btn-run-check')?.addEventListener('click', runAutoCheck);

  // Fullscreen CLI
  document.getElementById('btn-fullscreen')?.addEventListener('click', toggleFullscreen);

  // Input focus on click anywhere in terminal area
  document.getElementById('cli-area')?.addEventListener('click', () => {
    document.getElementById('cli-input').focus();
  });
}

function updateLabSelector(id) {
  const sel = document.getElementById('lab-selector');
  if (sel) sel.value = id;
}

function togglePanel() {
  panelVisible = !panelVisible;
  const panel = document.getElementById('lab-panel');
  const btn = document.getElementById('btn-toggle-panel');
  const workspace = document.getElementById('workspace');

  if (panelVisible) {
    panel.classList.remove('hidden');
    workspace.classList.remove('panel-hidden');
    btn.textContent = '◀ Masquer';
  } else {
    panel.classList.add('hidden');
    workspace.classList.add('panel-hidden');
    btn.textContent = '▶ Afficher';
  }
}

function toggleFullscreen() {
  const cliSection = document.getElementById('cli-section');
  cliSection.classList.toggle('fullscreen');
  const btn = document.getElementById('btn-fullscreen');
  btn.textContent = cliSection.classList.contains('fullscreen') ? '⊡ Normal' : '⊞ Plein écran';
}

// ============================================================
// PDF EXPORT
// ============================================================
async function exportPDF() {
  const btn = document.getElementById('btn-pdf');
  btn.textContent = '⏳ Génération...';
  btn.disabled = true;

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    const lab = currentLab;
    let y = 15;

    // Header
    doc.setFillColor(8, 12, 20);
    doc.rect(0, 0, 210, 25, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('LE DOJO DU NETWORKING', 15, 12);
    doc.setFontSize(9);
    doc.setTextColor(90, 122, 159);
    doc.text('Plateforme d\'entraînement réseau', 15, 19);
    doc.setTextColor(200, 222, 255);
    doc.text(new Date().toLocaleDateString('fr-FR'), 170, 12);

    y = 35;

    // Lab title
    doc.setFillColor(13, 21, 37);
    doc.roundedRect(10, y-5, 190, 18, 2, 2, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(13);
    doc.setFont('helvetica', 'bold');
    doc.text(lab.title, 15, y+7);
    y += 22;

    // Meta
    doc.setFontSize(9);
    doc.setTextColor(90, 122, 159);
    doc.text(`Difficulté: ${lab.difficulty}   Durée estimée: ${lab.duration}`, 15, y);
    y += 10;

    // Objectives
    doc.setFillColor(13, 21, 37);
    doc.rect(10, y, 190, 7, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('OBJECTIFS', 15, y+5);
    y += 12;

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(200, 222, 255);
    doc.setFontSize(9);
    lab.objectives.forEach((obj, i) => {
      const lines = doc.splitTextToSize(`${i+1}. ${obj}`, 175);
      doc.text(lines, 15, y);
      y += lines.length * 5 + 2;
    });
    y += 5;

    // Addressing table
    if (y > 240) { doc.addPage(); y = 20; }
    doc.setFillColor(13, 21, 37);
    doc.rect(10, y, 190, 7, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('TABLE D\'ADRESSAGE', 15, y+5);
    y += 10;

    // Table header
    doc.setFillColor(17, 29, 51);
    doc.rect(10, y, 190, 6, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(8);
    ['Appareil','Interface','Adresse IP','Masque','VLAN / Info'].forEach((h, i) => {
      doc.text(h, 12 + i*38, y+4);
    });
    y += 7;

    doc.setFont('helvetica', 'normal');
    lab.addressing.forEach((row, i) => {
      if (i % 2 === 0) { doc.setFillColor(8, 12, 20); doc.rect(10, y-1, 190, 6, 'F'); }
      doc.setTextColor(200, 222, 255);
      [row.device, row.interface, row.ip, row.mask, row.vlan].forEach((cell, ci) => {
        doc.text(String(cell||'').substring(0,18), 12+ci*38, y+3.5);
      });
      y += 6;
    });
    y += 8;

    // Instructions
    if (y > 220) { doc.addPage(); y = 20; }
    doc.setFillColor(13, 21, 37);
    doc.rect(10, y, 190, 7, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('INSTRUCTIONS', 15, y+5);
    y += 12;

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(200, 222, 255);
    doc.setFontSize(8.5);
    lab.instructions.forEach((instr, i) => {
      if (y > 265) { doc.addPage(); y = 20; }
      const clean = instr.replace(/<code>/g,'`').replace(/<\/code>/g,'`').replace(/<[^>]+>/g,'');
      const lines = doc.splitTextToSize(`${i+1}. ${clean}`, 173);
      doc.text(lines, 15, y);
      y += lines.length * 4.5 + 2;
    });
    y += 5;

    // Hint
    if (lab.hint) {
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFillColor(17, 29, 51);
      doc.roundedRect(10, y, 190, 14, 2, 2, 'F');
      doc.setTextColor(255, 204, 0);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.text('💡 Astuce :', 13, y+5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(200, 222, 255);
      const hintLines = doc.splitTextToSize(lab.hint, 165);
      doc.text(hintLines, 13, y+10);
      y += 20;
    }

    // Checklist
    if (y > 230) { doc.addPage(); y = 20; }
    doc.setFillColor(13, 21, 37);
    doc.rect(10, y, 190, 7, 'F');
    doc.setTextColor(0, 212, 255);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('LISTE DE VÉRIFICATION', 15, y+5);
    y += 12;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    lab.checklist.forEach(item => {
      const done = checklistState[item.id];
      doc.setTextColor(done ? 57 : 90, done ? 255 : 122, done ? 20 : 159);
      doc.text(done ? '✓' : '○', 13, y);
      doc.setTextColor(200, 222, 255);
      doc.text(item.label, 18, y);
      doc.setTextColor(0, 212, 255);
      doc.setFontSize(7);
      doc.text(`[${item.command}]`, 140, y);
      doc.setFontSize(8.5);
      y += 7;
    });

    // Footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFillColor(8, 12, 20);
      doc.rect(0, 285, 210, 12, 'F');
      doc.setFontSize(7);
      doc.setTextColor(90, 122, 159);
      doc.text('Le Dojo du Networking — Plateforme d\'entraînement réseau', 15, 291);
      doc.text(`Page ${i}/${pageCount}`, 185, 291);
    }

    doc.save(`dojo-lab-${lab.id}-${lab.title.replace(/[^a-z0-9]/gi,'-').toLowerCase()}.pdf`);
  } catch(e) {
    console.error('PDF error:', e);
    alert('Erreur PDF. Assurez-vous que jsPDF est chargé.');
  }

  btn.textContent = '⬇ PDF';
  btn.disabled = false;
}

// ============================================================
// AUTO CHECKLIST RUNNER
// ============================================================
function runAutoCheck() {
  if (!currentLab) return;
  const fb = document.getElementById('feedback-msg');
  fb.innerHTML = '<div class="feedback-running">⏳ Vérification en cours...</div>';

  let delay = 0;
  currentLab.checklist.forEach(item => {
    setTimeout(() => {
      const dev = DEVICES[currentLab.initial_config];
      const fakeOutput = simulateShowOutput(dev, item.command);
      const re = new RegExp(item.expect, 'i');
      const pass = re.test(fakeOutput);

      if (pass && !checklistState[item.id]) {
        checklistState[item.id] = true;
        const el = document.getElementById(`chk-${item.id}`);
        if (el) { el.classList.add('done'); el.querySelector('.check-icon').textContent = '✅'; }
        updateScore();
      }

      const el2 = document.getElementById(`chk-${item.id}`);
      if (el2) el2.classList.add(pass ? 'check-pass' : 'check-fail');
    }, delay);
    delay += 300;
  });

  setTimeout(() => {
    const done = Object.values(checklistState).filter(Boolean).length;
    const total = currentLab.checklist.length;
    fb.innerHTML = done === total
      ? `<div class="feedback-win">🎉 ${done}/${total} — Lab complété avec succès !</div>`
      : `<div class="feedback-partial">📊 ${done}/${total} objectifs validés. Continuez !</div>`;
  }, delay + 200);
}

function simulateShowOutput(dev, command) {
  const parts = command.split(' ');
  return cmdShow(dev, parts.slice(1));
}

// ============================================================
// DEVICE RESET
// ============================================================
function resetDevices() {
  Object.keys(DEVICES).forEach(key => {
    DEVICES[key] = {
      ...DEVICES[key],
      mode: 'exec',
      configContext: null,
      vlans: { 1: 'default' },
      interfaces: {},
      trunk: {},
      portSecurity: {},
      routes: [],
      routing: false,
    };
  });
}

// ============================================================
// UTILS
// ============================================================
function maskToPrefix(mask) {
  if (!mask) return 24;
  return mask.split('.').reduce((acc, o) => {
    let n = parseInt(o), c = 0;
    while (n > 0) { c += n & 1; n >>= 1; }
    return acc + c;
  }, 0);
}

function ipToNetwork(ip, mask) {
  if (!ip) return '0.0.0.0/0';
  const prefix = maskToPrefix(mask);
  const parts = ip.split('.').map(Number);
  const maskParts = mask ? mask.split('.').map(Number) : [255,255,255,0];
  const net = parts.map((p, i) => p & maskParts[i]);
  return `${net.join('.')}/${prefix}`;
}

function randomHex(n) {
  return Math.floor(Math.random() * Math.pow(16, n)).toString(16).padStart(n, '0');
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function showError(msg) {
  document.getElementById('lab-title').textContent = '⚠ ' + msg;
}

// ============================================================
// WINDOW RESIZE → redraw topology
// ============================================================
window.addEventListener('resize', () => {
  if (currentLab) drawTopology(currentLab.topology);
});
